CHAMUNDA SALES Billing App (Simple Billing, no GST)

Android use:
1. Copy index.html to your Android phone (or open it from a downloaded ZIP).
2. Extract CHAMUNDA_SALES_BILLING_APP.zip.
3. Open index.html using Chrome.
4. For easier access, in Chrome tap ⋮ > Add to Home screen (if available).

Features:
- Simple bill without GST
- Add multiple items, quantity and price
- Save bills in this browser on this phone
- Print / Save as PDF
- Share bill text using Android share sheet / WhatsApp
- Bill history and JSON backup

Important:
- This is a lightweight browser app, not a Play Store APK.
- Bills are stored locally in browser storage on this device. Export a backup regularly.
- Shop details currently set to CHAMUNDA SALES, phone 9016994803, address Raha, Vav, Tharad.
- Edit index.html if you need to change shop details.
